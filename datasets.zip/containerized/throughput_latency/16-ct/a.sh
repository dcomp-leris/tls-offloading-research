mv 2023-09-27-03-02-34-wrk_noktls-16.csv noktls-1.csv
mv 2023-09-27-03-34-37-wrk_noktls-16.csv noktls-8.csv
mv 2023-09-27-04-06-41-wrk_noktls-16.csv noktls-16.csv
mv 2023-09-27-04-38-45-wrk_noktls-16.csv noktls-32.csv
mv 2023-09-27-05-13-24-wrk_swktls-16.csv swktls-1.csv
mv 2023-09-27-05-45-28-wrk_swktls-16.csv swktls-8.csv
mv 2023-09-27-06-17-31-wrk_swktls-16.csv swktls-16.csv
mv 2023-09-27-06-49-36-wrk_swktls-16.csv swktls-32.csv
mv 2023-09-27-07-25-16-wrk_coprocessor-16.csv coprocessor-1.csv
mv 2023-09-27-07-57-20-wrk_coprocessor-16.csv coprocessor-8.csv
mv 2023-09-27-08-29-23-wrk_coprocessor-16.csv coprocessor-16.csv
mv 2023-09-27-09-01-27-wrk_coprocessor-16.csv coprocessor-32.csv

